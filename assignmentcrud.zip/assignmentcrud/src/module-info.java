/**
 * 
 */
/**
 * 
 */
module assignmentcrud {
requires java.sql;}