package assignmentonecrudoperation;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class EmployeeInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			
				String dbURL = "jdbc:mysql://localhost:3306/employeedb";
				String username = "root";
				String password = "anusha";
				 
				try {
				 
				    Connection conn = DriverManager.getConnection(dbURL, username, password);
				    String sql = "INSERT INTO employee (empname, empsalary, empaddress, empage) VALUES (?, ?, ?, ?)";
				    PreparedStatement statement = conn.prepareStatement(sql);
				    statement.setString(1, "suresh");
				    statement.setString(2, "23000");
				    statement.setString(3, "chennai");
				    statement.setString(4, "30");
				    PreparedStatement statement1 = conn.prepareStatement(sql);
				    statement1.setString(1, "anusha");
				    statement1.setString(2, "45000");
				    statement1.setString(3, "bangalore");
				    statement1.setString(4, "20");
				    PreparedStatement statement2 = conn.prepareStatement(sql);
				    statement2.setString(1, "shanmukhi");
				    statement2.setString(2, "25000");
				    statement2.setString(3, "punjab");
				    statement2.setString(4, "21");
				    PreparedStatement statement3 = conn.prepareStatement(sql);
				    statement3.setString(1, "ashwini");
				    statement3.setString(2, "30000");
				    statement3.setString(3, "delhi");
				    statement3.setString(4, "22");
				     
				    int rowsInserted = statement.executeUpdate();
				    if (rowsInserted > 0) {
				        System.out.println("A new employee1 was inserted successfully!");
				    }
				    int rowsInserted1 = statement1.executeUpdate();
				    if (rowsInserted1 > 0) {
				        System.out.println("A new employee2 was inserted successfully!");
				    }
				    int rowsInserted2 = statement2.executeUpdate();
				    if (rowsInserted2 > 0) {
				        System.out.println("A new employee3 was inserted successfully!");
				    }
				    int rowsInserted3 = statement3.executeUpdate();
				    if (rowsInserted3 > 0) {
				        System.out.println("A new employee4 was inserted successfully!");
				    }
				} catch (SQLException ex) {
				    ex.printStackTrace();
				}

		


	}

}
