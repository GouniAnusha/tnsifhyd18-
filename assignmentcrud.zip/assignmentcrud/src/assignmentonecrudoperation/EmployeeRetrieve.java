package assignmentonecrudoperation;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class EmployeeRetrieve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
				String dbURL = "jdbc:mysql://localhost:3306/employeedb";
				String username = "root";
				String password = "anusha";
				 
				try(Connection conn = DriverManager.getConnection(dbURL, username, password)) {
				 
					String sql = "SELECT * FROM employee";
					 
					Statement statement = conn.createStatement();
					ResultSet result = statement.executeQuery(sql);
					 
					int count = 80;
					 
					while (result.next()){
					    String salary = result.getString(3);
					    String age = result.getString(5);
					    String name = result.getString("empname");
					    String address = result.getString("empaddress");
					 
					    String output = "empid #%d: %s - %s - %s - %s";
					    System.out.println(String.format(output, ++count, name, salary, address, age));
					}
				} catch (SQLException ex) {
				    ex.printStackTrace();
				}

			}
			}



	
