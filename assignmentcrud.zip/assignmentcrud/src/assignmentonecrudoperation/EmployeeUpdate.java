package assignmentonecrudoperation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				String dbURL = "jdbc:mysql://localhost:3306/employeedb";
				String username = "root";
				String password = "anusha";
				 
				try {
				 
				    Connection conn = DriverManager.getConnection(dbURL, username, password);
				    String sql = "UPDATE employee SET empname=?, empsalary=?, empaddress=? WHERE empage=?";
				    
				    PreparedStatement statement = conn.prepareStatement(sql);
				    statement.setString(1, "lavanya");
				    statement.setString(2, "34000");
				    statement.setString(3, "delhi");
				    statement.setString(4, "21");
				    PreparedStatement statement1 = conn.prepareStatement(sql);
				    statement1.setString(1, "sindu");
				    statement1.setString(2, "44000");
				    statement1.setString(3, "mumbai");
				    statement1.setString(4, "22");
				    int rowsUpdated = statement.executeUpdate();
				    if (rowsUpdated > 0) {
				        System.out.println("An existing employee was updated successfully!");
				    }
				    int rowsUpdated1 = statement1.executeUpdate();
				    if (rowsUpdated1 > 0) {
				        System.out.println("An existing employee was updated successfully!");
				    }
				} catch (SQLException ex) {
				    ex.printStackTrace();
				}
			}
			}


