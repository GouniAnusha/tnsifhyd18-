package com.day1.pack;

public class Default2 {
	public static void main(String args[])
	{
	//accessing class MyClass1 from package p1
		Default obj = new Default();
	obj.display();
	}
	}


