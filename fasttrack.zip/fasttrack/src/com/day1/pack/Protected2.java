package com.day1.pack;

import com.day1.Protected;

public class Protected2 extends Protected{
	public static void main(String[] args)
	{
		 Protected2 obj = new  Protected2();
	obj.display1();
	}
	}

