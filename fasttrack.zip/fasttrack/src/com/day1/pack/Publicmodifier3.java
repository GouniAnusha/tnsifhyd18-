package com.day1.pack;
import com.day1.*;
public class Publicmodifier3 {
	public static void main(String[] args)
	{
		Publicmodifier obj = new Publicmodifier();
	obj.display();
	}
	}


