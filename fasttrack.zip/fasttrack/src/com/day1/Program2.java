package com.day1;
import java.util.*;
public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner ln=new Scanner(System.in);
System.out.println("enter a number");
int num1;
num1=ln.nextInt();
if(num1%2==0)
{
	System.out.println("even number");
	
}
else
{
	System.out.println("odd number");
}
	}

}
