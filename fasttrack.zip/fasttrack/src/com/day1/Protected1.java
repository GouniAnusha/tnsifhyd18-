package com.day1;
import com.day1.*;
public class Protected1 extends  Protected {
	
	public static void main(String[] args)
	{
		 Protected1 obj = new  Protected1();
	obj.display1();
	}
	}


