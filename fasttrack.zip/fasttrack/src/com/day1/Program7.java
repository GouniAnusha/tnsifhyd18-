package com.day1;
import java.util.*;
public class Program7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner input= new Scanner(System.in);
System.out.println("enter first number");
int num1=input.nextInt();
System.out.println("enter second number");
int num2=input.nextInt();
System.out.println("enter third number");
int num3=input.nextInt();
int largest;
if(num1>=num2 &&num1>=num3)
{
	largest=num1;
}
if(num2>=num1 &&num2>=num3)
{
	largest=num2;
}
else 
{
	largest=num3;
	
}
System.out.println("the largest number"+largest);
	}

}
