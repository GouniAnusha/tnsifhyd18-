package com.day1;

public class Program5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n=10,i;
int a=0,b=1,c;
for(i=2;i<n;i++)
{
	c=a+b;
	System.out.println(""+c);
	a=b;
	b=c;
}
	}

}
