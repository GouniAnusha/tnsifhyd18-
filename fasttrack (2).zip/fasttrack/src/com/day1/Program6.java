package com.day1;
import java.util.*;
public class Program6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

Scanner rs=new Scanner(System.in);
System.out.println("enter a string");
String str=rs.nextLine();
String reversedstr="";
for(int i=str.length()-1;i>=0;i--){
	reversedstr+=str.charAt(i);
	
}
System.out.println("reversed string"+reversedstr);
	
}

}
