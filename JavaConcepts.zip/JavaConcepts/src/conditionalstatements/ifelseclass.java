package conditionalstatements;

public class ifelseclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
if(5<2)
{
	System.out.println("5 is less than 2");
}
else
	System.out.println("5 is greater than 2");
	}

}
