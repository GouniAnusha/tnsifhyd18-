package conditionalstatements;

public class ifclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
if(5>2)
{
	System.out.println("5 is greater than 2");
}
	}

}
