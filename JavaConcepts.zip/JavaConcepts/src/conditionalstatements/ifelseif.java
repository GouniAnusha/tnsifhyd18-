package conditionalstatements;

public class ifelseif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int	age=18;
if(age>18) {
	System.out.println("eligible for voting");
}
else if(age==18)
{
	System.out.println("also eligible for voting");
}
else
	System.out.println("not eligible for voting");
	}

}
