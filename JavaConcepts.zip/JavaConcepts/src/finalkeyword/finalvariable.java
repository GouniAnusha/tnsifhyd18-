package finalkeyword;

public class finalvariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
final int a=10;
//a=6; //because it is final(fixed or constant)
System.out.println("a="+a);
	}

}
