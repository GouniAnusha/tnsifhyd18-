package finalkeyword;

public final class finalclass {
	void marks()
	{
		System.out.println("final class");
	}
}
