package finalkeyword;

public class finalmethod1 extends finalmethod {
/*void name()
{
	System.out.println("child name");
}*///cannot override final method
	public static void main(String[] args) {
		// TODO Auto-generated method stub
finalmethod1 f=new finalmethod1();
f.name();
	}

}
