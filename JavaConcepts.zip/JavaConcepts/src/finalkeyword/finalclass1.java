package finalkeyword;

public class finalclass1 //extends finalclass {
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("cannot inherit because it is final class");
	}

}
