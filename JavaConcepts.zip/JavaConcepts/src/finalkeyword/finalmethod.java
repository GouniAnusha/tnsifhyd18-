package finalkeyword;

public class finalmethod {
final void name()
{
	System.out.println("parent name");
}
}
