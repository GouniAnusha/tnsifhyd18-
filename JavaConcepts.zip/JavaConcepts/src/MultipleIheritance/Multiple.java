package MultipleIheritance;

public interface Multiple {
	//abstract method
	public void connect() ;
}
