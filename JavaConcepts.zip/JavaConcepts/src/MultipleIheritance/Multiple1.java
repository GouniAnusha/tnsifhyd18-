package MultipleIheritance;

public class Multiple1 {

	
	public void response(String str) {
	    System.out.println(str + " can also connect");
	  }


	}


