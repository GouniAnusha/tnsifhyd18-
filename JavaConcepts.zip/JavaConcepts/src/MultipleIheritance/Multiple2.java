package MultipleIheritance;



public class Multiple2 extends Multiple1 implements Multiple{
	String language = "Java";

	  // implement method of interface
	  public void connect() {
	    System.out.println(language + " can be used in reponse");
	  }

	  public static void main(String[] args) {

	   
		  Multiple2 java = new Multiple2();

	    java.connect();
	
	    java.response(java.language);
	  }

}
