
package accessmodifiers1;

import accessmodifiers.public1;
public class publicmain2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    public1 p2=new public1();
p2.sample();
System.out.println("accessible from other package");
	}

}
