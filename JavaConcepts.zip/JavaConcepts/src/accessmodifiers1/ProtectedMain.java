package accessmodifiers1;
import accessmodifiers.*;
import java.lang.*;
public class ProtectedMain extends protected1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProtectedMain p3=new ProtectedMain();
p3.display1();
	}

}
