package abstracts;



public class Abstractclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person john = new Veg();
		john.speak();
		john.eat();
		System.out.println("=======================");
		Person mia = new Nonveg();
		mia.speak();
		mia.eat();
	}

	}


