package abstracts;

public  class Nonveg extends Person{
	public void eat() {
		System.out.println("Eats Nonveg");
}
}