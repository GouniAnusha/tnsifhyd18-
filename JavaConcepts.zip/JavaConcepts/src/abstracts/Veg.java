package abstracts;

public class Veg extends Person{
	public void eat() {
		System.out.println("Eats veg");
}
}
