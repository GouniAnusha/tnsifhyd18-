package multithreadingextendingclass;



public class MultiThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		{
			int n = 8; // Number of threads
			for (int i = 0; i < n; i++) {
				MultiThreading object = new MultiThreading();
				object.start();
			}
		}
	}

}
