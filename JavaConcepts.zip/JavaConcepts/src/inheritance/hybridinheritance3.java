package inheritance;

public class hybridinheritance3 extends hybridinheritance1 {
//combination of multilevel,hierarical inheritance is hybrid inheritance
	void college()
	{
		System.out.println("student college ");
	}
}
