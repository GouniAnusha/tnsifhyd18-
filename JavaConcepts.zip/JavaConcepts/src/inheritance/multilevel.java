package inheritance;

public class multilevel {
void display()
{
	System.out.println("parent");
}
}
