package inheritance;

public class multilevel2 extends multilevel1 {
void page()
{
	System.out.println("child2");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 multilevel2 m2=new  multilevel2();
		 m2.page();
		 m2.sample();
		 m2.display();
	}

}
