package inheritance;



public class singleinheritance1 extends singleinheritance {
public void print() {
		
		System.out.println("I am a method from  child class");
	}
	
	public static void main(String[] args) {
		
		singleinheritance1 obj = new singleinheritance1();
		obj.display();
		obj.print();
}
}	
