package inheritance;

public class hierarichalinheritance1 extends hierarichalinheritance {
void display()
{
	System.out.println("child1");
}
}
