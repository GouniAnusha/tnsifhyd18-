package inheritance;

public class hierarichalinheritance2 extends hierarichalinheritance  {
void name()
{
	System.out.println("child2");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hierarichalinheritance2 i=new hierarichalinheritance2();
		i.sample();
		i.name();
		hierarichalinheritance1 i1=new hierarichalinheritance1();
		i1.sample();
		i1.display();
		
	}

}
