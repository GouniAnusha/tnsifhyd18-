package inheritance;

public class HybridinheritanceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hybridinheritance3 h=new hybridinheritance3();
		h.college();
		h.roll();
		h.student();
		//h.marks(); not accessible
	}

}
