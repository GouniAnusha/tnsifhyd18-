package inheritance;

public class hybridinheritance1 extends hybridinheritance {
void roll()
{
	System.out.println("student roll no");
}
}
