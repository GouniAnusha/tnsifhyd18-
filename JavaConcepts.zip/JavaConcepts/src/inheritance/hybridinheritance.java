package inheritance;

public class hybridinheritance {
void student()
{
	System.out.println("student details");
}
}
