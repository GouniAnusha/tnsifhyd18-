package inheritance;

public class hierarichalinheritance {
void sample()
{
	System.out.println("parent");
}
}
