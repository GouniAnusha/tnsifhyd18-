package inheritance;

public class singleinheritance {
	public void display() {
		System.out.println("I am a method from parent class");
	}
}
