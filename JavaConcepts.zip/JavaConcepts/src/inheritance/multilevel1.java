package inheritance;

public class multilevel1 extends multilevel{
void sample()
{
	System.out.println("child1");
}
}
