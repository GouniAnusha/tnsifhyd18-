package inheritance;

public class hybridinheritance2  extends hybridinheritance{
void marks()
{
	System.out.println("student marks secured");
}
}
