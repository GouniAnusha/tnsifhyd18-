package Interfaces;

public interface Tree {

	String root(); //abstract method 
	String branch(); // abstract method
	int leaves(); //abstract method

}
