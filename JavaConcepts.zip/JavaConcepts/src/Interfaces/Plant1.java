package Interfaces;



public class Plant1 implements Tree {
	@Override
	public String branch() {
		// TODO Auto-generated method stub
		return "lilybranches";
	}

	@Override
	public String root() {
		// TODO Auto-generated method stub
		return "lilyroots";
	}

	@Override
	public int leaves() {
		// TODO Auto-generated method stub
		return 3000;
	}
	
	public static void main(String[] args) {
		Tree t = new Plant1();
		System.out.println("root "+ t.root());
		System.out.println("branch "+ t.branch());
		System.out.println("leaves "+ t.leaves());
		
		Tree t1 = new Plant();
		System.out.println("root "+ t1.root());
		System.out.println("branch "+ t1.branch());
		System.out.println("leaves "+ t1.leaves());
	}

}