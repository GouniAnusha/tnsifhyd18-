package Interfaces;

public class Plant implements Tree {
	@Override
	public String branch() {
		// TODO Auto-generated method stub
		return "rosebranches";
	}

	@Override
	public String root() {
		// TODO Auto-generated method stub
		return "roseroots";
	}

	@Override
	public int leaves() {
		// TODO Auto-generated method stub
		return 2000;
}
}