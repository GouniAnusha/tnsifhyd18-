package filehandling;

import java.io.File;

public class Delete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File myObj = new File("anushagoud.txt"); 
	    if (myObj.delete()) { 
	      System.out.println("Deleted the file: " + myObj.getName());
	    } else {
	      System.out.println("Failed to delete the file.");
	    } 
	}
	}


