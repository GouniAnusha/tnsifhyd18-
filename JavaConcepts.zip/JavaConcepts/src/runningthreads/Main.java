package runningthreads;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class1 c1 = new Class1();

		c1.start();
		
	}

}
