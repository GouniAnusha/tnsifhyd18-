package runningthreads;

public class Class1 extends Thread{
	public void run() {
		System.out.println("Run method of Class1");
	}
}
