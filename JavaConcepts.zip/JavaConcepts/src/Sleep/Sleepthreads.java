package Sleep;



public class Sleepthreads extends Thread{
	public void run(){  
		  for(int i=1;i<=5;i++){  
		    try{Thread.sleep(500);}
		    catch(InterruptedException e)
		    {System.out.println(e);}  
		    System.out.println(i);  
		  }  
		 }  
		 public static void main(String args[]){  
		  Sleepthreads t1=new  Sleepthreads();  
		t1.start();  
		}  
}
