package javaconcepts;

public class InstanceStatic {
int a=30;
static int c=19;
void display()
{
	System.out.println("instance method");
	System.out.println(a);//instance method can access both instance and static
	System.out.println(c);
}
static void print()
{
	System.out.println("static method");
System.out.println(c);//static method can access only static members
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
InstanceStatic s=new InstanceStatic();
s.display();
InstanceStatic.print();
	}

}
