package accessmodifiers;

public class private1 {
private void page()
{
	System.out.println("accessible within the class");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	private1 p2=new private1();
	p2.page();
	
	}
}
