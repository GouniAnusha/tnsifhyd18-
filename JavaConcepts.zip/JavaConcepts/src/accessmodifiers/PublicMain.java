package accessmodifiers;

public class PublicMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
  public1 p1=new public1();
  p1.sample();
 //public access modifiers is used to access data from everywhere like outside the package,outside the class etc..,,
  
	}

}
