package accessmodifiers;

public class default1 {
void sample()
{
	System.out.println("accessible from other package(if accessmodifier is not mentioned then considered as default)");
}
}
