package accessmodifiers;

public class protected1 {
protected void display1()
{
	System.out.println("accessible from other package(outside class)only through inheritance");
}
}
