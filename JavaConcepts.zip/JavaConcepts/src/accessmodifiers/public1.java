package accessmodifiers;

public class public1 {
public void sample()
 {
	 System.out.println("accessible from everywhere");
 }
}
