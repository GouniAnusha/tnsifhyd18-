package Encapsulation;
public class AccessingPrivateMembersMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessingPrivateMembers e3 = new AccessingPrivateMembers();
		e3.setAge(20);
		e3.setGender("Female");
		e3.setName("Anusha");
		
		System.out.println(e3.getAge());
		System.out.println(e3.getGender());
		System.out.println(e3.getName());
	}

}
