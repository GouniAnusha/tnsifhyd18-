package superkeyword;

public class SuperParentClass {

	public SuperParentClass()
	{super();
		System.out.println("parent class created");
	}

}
