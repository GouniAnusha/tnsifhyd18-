package superkeyword;

public class SuperChildVariable  extends  SuperParentVariable{
String name="bindu";
void studentName()
{
	System.out.println(name);
	System.out.println(super.name);
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SuperChildVariable s= new  SuperChildVariable();
		 s.studentName();
	}

}
