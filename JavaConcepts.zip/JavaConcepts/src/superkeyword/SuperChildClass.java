package superkeyword;

public class SuperChildClass extends SuperParentClass{

	public SuperChildClass() {
		super();
		System.out.println("child class is created");  
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SuperChildClass a=new SuperChildClass();

	}

}
