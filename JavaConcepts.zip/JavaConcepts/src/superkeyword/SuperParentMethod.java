package superkeyword;

public class SuperParentMethod {
	
	void eat() {
		System.out.println("eating...");
	}

}
