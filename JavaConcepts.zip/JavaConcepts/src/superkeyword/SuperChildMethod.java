package superkeyword;

public class SuperChildMethod extends  SuperParentMethod {
void walk()
{
	System.out.println("walking");
	super.eat();
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
SuperChildMethod s=new SuperChildMethod();
s.walk();
	}

}
