package superkeyword;

public class SuperParentVariable {
String name="anusha";
}
