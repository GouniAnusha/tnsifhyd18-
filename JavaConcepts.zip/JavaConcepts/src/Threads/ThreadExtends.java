package Threads;



public class ThreadExtends {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student e1 = new Student();
		e1.start();	
		
		 Class m1 = new Class(); 
		 m1.start();
				
		System.out.println(Thread.activeCount());
		
	}

}
class Student extends Thread{
	
	@Override
	public void run() {
		System.out.println("student name");
	}
	
}



 class Class extends Thread{
 
  @Override 
  public void run() 
  { 
	  System.out.println("student class"); 
	  
  }
 
  
	}


