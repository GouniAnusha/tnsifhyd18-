package Threads;



public class ThreadImplements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student1 e1 = new Student1();
		Thread t1 = new Thread(e1);
		t1.start();
		
		
		  Class1 m1 = new Class1(); 
		  Thread t2 = new Thread(m1);
		  t2.start();
		 
			
		System.out.println(Thread.activeCount());
		
	}

}

class Student1 implements Runnable{

	@Override
	public void run() {
		System.out.println("student name is");
		
	}
}


class Class1 implements Runnable{
 
  @Override public void run() 
  { 
	  System.out.println("student class is");
  
  }
  
	}


