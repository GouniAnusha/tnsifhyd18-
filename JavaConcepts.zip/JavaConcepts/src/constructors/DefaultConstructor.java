package constructors;

public class DefaultConstructor {
	private String doors;
	private String engine;
	private String driver;
	private int speed;
	
	public DefaultConstructor() {
		doors = "closed";
		engine = "on";
		driver= "seated";
		speed = 10;
	}
	
	public String run() {
		if(doors.equals("closed") && engine.equals("on")&& driver.equals("seated") 
				&& speed >0) {
			return "vehicle is running";
		}
		else{
			return "vehicle is not running";
		}
	}

}


