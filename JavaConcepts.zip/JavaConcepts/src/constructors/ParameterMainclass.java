package constructors;

public class ParameterMainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ParameterizedConstructor c2 = new ParameterizedConstructor("closed"	, "on", "seated", 10);
		
		System.out.println(c2.run());
	}
	}


