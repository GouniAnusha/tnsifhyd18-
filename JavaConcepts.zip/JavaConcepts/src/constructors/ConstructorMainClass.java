package constructors;

public class ConstructorMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			DefaultConstructor c1 = new DefaultConstructor();
			System.out.println(c1.run());
	}

}
