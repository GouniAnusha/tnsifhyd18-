package Scanners;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class userinput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // creates an object of Scanner
	    Scanner input = new Scanner(System.in);
	    System.out.print("Enter Double value: ");

	    // reads the double value
	    double value = input.nextDouble();
	    System.out.println("Using nextDouble(): " + value);
	    System.out.print("Enter a big integer: ");

	    // reads the big integer
	    BigInteger value1 = input.nextBigInteger();
	    System.out.println("Using nextBigInteger(): " + value1);

	    System.out.print("Enter a big decimal: ");

	    // reads the big decimal
	    BigDecimal value2 = input.nextBigDecimal();
	    System.out.println("Using nextBigDecimal(): " + value2);
	    System.out.println("Enter an integer: ");

	    // reads an int value
	    int data1 = input.nextInt();

	    System.out.println("Using nextInt(): " + data1);
	 

	    input.close();
	}

}
