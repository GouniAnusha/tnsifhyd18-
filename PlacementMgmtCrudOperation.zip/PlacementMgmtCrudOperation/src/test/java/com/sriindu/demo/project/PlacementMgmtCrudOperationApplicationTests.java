package com.sriindu.demo.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementMgmtCrudOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
