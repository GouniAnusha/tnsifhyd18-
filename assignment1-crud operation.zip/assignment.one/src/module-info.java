/**
 * 
 */
/**
 * 
 */
module assignment.one {
	requires java.sql;
}