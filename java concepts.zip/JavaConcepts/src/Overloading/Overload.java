package Overloading;
public class Overload {
	public static void foo() {
		System.out.println("Test.foo() called ");
	}

	
	  public void foo(int a) { 
	  System.out.println("Test.foo(int) called "); }
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	
			Overload.foo();
			
			Overload t1 = new Overload();
			t1.foo(1);
		}
	}
//we can overload both static and instance members
