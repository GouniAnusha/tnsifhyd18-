package overriding;


public class Override {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 BaseClass obj = new DerivedClass();
	        
	       // As per overriding rules this should call to class Derive's static
	       // overridden method. Since static method can not be overridden, it
	       // calls Base's display()
	       BaseClass.display(); 
	        
	       // Here overriding works and Derive's print() is called
	       obj.print();    
	    }
}

