package com.day3;

public class SuperParentClassMethod {
	
	void eat() {
		System.out.println("eating...");
	}

}
