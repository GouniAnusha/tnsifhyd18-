package com.day3;

public class Dog extends Animal{
	
	public void display() {
		System.out.println("My name is " + name);
	}

}
