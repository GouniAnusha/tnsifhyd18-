package com.day3;

public interface interface2 {
}
