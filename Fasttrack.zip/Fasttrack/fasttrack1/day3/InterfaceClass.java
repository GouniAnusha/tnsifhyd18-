package com.day3;

public class InterfaceClass implements Interface1,interface2 {
public void fun()
{
	System.out.println("fun method in interface1");
}
public void act()
{
	System.out.println("act method in interface2");
}
}
