package com.day3;

public class MultilevelInheritance1 {
	
	String getName() {
		return "progrramerBay";
	}

}
