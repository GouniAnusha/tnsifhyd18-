package com.day3;

public class Animal {
	
	String name;
	public void eat() {
		System.out.println("I can eat");
	}

}
