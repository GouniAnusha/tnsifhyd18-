package com.day3;

public class SuperParentClassConstructor {
	
	SuperParentClassConstructor(){
		System.out.println("parent class is created");
	}
	
}
