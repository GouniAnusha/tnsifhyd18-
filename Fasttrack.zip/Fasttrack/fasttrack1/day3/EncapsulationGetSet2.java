package com.day3;

public class EncapsulationGetSet2 {
	
	public String name="john";
	public int age=25;
	public String gender="Male";

}


