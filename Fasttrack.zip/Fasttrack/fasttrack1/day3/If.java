package com.day3;

public class If {
	
		public static void main(String[] args) {  
		    int num=20;  
		    if(num>0){  
		        System.out.print("Positive");  
		    }  
		}  
		}

