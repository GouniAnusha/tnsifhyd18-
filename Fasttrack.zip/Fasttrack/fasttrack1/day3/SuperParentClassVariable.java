package com.day3;

public class SuperParentClassVariable {
	
	String color="white";

}
