package com.day3;

public class AnimalSuper {
	
	
	public void eat() {
		System.out.println("I can eat");
	}

}
