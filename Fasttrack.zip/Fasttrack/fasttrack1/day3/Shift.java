package com.day3;

public class Shift implements CarInterface{

	@Override
	public String belt() {
		// TODO Auto-generated method stub
		return "no seatbelt wored";
	}

	@Override
	public String door() {
		// TODO Auto-generated method stub
		return "closed";
	}

	@Override
	public int window() {
		// TODO Auto-generated method stub
		return 6;
	}
	
	public static void main(String[] args) {
		CarInterface c1 = new Bmw();
		System.out.println("belt: "+ c1.belt());
		System.out.println("door: "+ c1.door());
		System.out.println("window: "+ c1.window());
		
		CarInterface c2 = new Shift();
		System.out.println("belt: "+ c2.belt());
		System.out.println("Processor: "+ c2.door());
		System.out.println("spaceinGB: "+ c2.window());
	}

}



