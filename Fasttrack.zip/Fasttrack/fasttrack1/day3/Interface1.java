package com.day3;

public interface Interface1 {
public void fun();
}
