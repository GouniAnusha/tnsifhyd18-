package com.day3;

public class MainPrivateEncapsulation {
	
	public static void main(String[] args) {
		
		PrivateEncapsulation e3 = new PrivateEncapsulation();
		e3.setAge(25);
		e3.setGender("Male");
		e3.setName("John");
		
		System.out.println(e3.getAge());
		System.out.println(e3.getGender());
		System.out.println(e3.getName());
		
	}
}
