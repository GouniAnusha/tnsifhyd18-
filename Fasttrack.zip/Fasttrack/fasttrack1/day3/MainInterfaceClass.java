package com.day3;

public class MainInterfaceClass {
public static void main(String[] args) {
	 InterfaceClass i=new  InterfaceClass();
	 i.fun();
	 i.act();
}
}
