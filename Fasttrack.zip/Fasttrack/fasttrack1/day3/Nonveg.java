package com.day3;

public class Nonveg extends Person {
	

	@Override
	public void eat() {
		System.out.println("Eats Nonveg");
	}

}
