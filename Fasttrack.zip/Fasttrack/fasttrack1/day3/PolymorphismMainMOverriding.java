package com.day3;

public class PolymorphismMainMOverriding {
	
	public static void main(String[] args) {
		
		PolymorphismOverriding p1 = new PolymorphismOverriding();
		p1.displayInfo();
		
		Polymorphism1MOverriding p2 = new Polymorphism1MOverriding();
		p2.displayInfo();
	}

}	