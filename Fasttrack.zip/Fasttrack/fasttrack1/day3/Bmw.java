package com.day3;

public class Bmw implements CarInterface{

	@Override
	public String belt() {
		// TODO Auto-generated method stub
		return "seatbelt wored";
	}

	@Override
	public String door() {
		// TODO Auto-generated method stub
		return "opened";
	}

	@Override
	public int window() {
		// TODO Auto-generated method stub
		return 4;
	}

}
