package com.day3;

public class SuperChildClassvariable extends SuperParentClassVariable {
	
	String color="black";
	
	void printColor(){  
		System.out.println(color);//prints color of Dog class  
		System.out.println(super.color);//prints color of Animal class  
	}  
	
	public static void main(String[] args) {
		
		SuperChildClassvariable a1 = new SuperChildClassvariable();
		a1.printColor();
		
	}
}
