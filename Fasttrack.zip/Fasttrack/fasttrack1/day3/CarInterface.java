package com.day3;

public interface CarInterface {
	
	String belt(); //abstract method 
	String door(); // abstract method
	int window(); //abstract method

}
