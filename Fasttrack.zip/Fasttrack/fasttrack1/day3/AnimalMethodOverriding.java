package com.day3;

public class AnimalMethodOverriding {
	
	// method in the superclass
	  public void eat() {
	    System.out.println("I can eat");
	  }

}
