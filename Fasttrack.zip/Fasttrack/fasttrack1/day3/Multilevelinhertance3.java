package com.day3;

public class Multilevelinhertance3 extends Multilevelinheritance2{
	
	int getLineofCode() {
		return 20;
	}
	
	public static void main(String[] args) {
		Multilevelinhertance3 mp3 = new Multilevelinhertance3();
		System.out.println("I am "+mp3.getName()+" and I code in " + mp3.getCodinglanguage()+" . This Program has" + mp3.getLineofCode()+" lines");
	}

}
