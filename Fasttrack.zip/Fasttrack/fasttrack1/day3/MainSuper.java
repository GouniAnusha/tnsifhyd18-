package com.day3;

public class MainSuper {
	
	public static void main(String[] args) {
		
		
		DogSuper labrador = new DogSuper();
		labrador.eat();
		labrador.bark();
		
	}

}
