package com.day3;

public class Multilevelinheritance2 extends MultilevelInheritance1{
	
	String getCodinglanguage() {
		return "Java";
	}

}
