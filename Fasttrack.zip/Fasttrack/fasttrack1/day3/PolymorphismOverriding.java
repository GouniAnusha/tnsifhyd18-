package com.day3;

public class PolymorphismOverriding extends Polymorphism1MOverriding {
	
	@Override
	  public void displayInfo() {
	    System.out.println("Java Programming Language");
	  }

}
