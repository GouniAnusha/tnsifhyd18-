package com.day3;

public interface Interfaces {
	
	//abstract method
	public void connectServer() ;

}
