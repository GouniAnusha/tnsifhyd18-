package com.day3;

public class SuperChildClassConstructor extends SuperParentClassConstructor {
	
		SuperChildClassConstructor(){  
		super();  
		System.out.println("child class is created");  
		}  
		
		public static void main(String[] args) {
			
			SuperChildClassConstructor a3 = new SuperChildClassConstructor(); //object
			
		}


}
