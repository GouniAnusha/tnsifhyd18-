package com.day3;

public class EncapsulationGetSet {
	
	private String name="john";
	private int age=25;
	private String gender="Male";
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	public String getGender() {
		return gender;
	}
	
	public static void main(String[] args) {
		EncapsulationGetSet e2 = new EncapsulationGetSet();
		
		
		System.out.println(e2.getAge());
		System.out.println(e2.getName());
		System.out.println(e2.getGender());
	
	}

}
