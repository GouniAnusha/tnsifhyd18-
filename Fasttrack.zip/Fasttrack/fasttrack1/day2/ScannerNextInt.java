package com.day2;

import java.util.Scanner;

public class ScannerNextInt {
	public static void main(String[] args) {
		System.out.println("enter integer value");
		Scanner input= new Scanner(System.in);
		int intvalue=input.nextInt();
		System.out.println("entered integer value  is  "+intvalue);
		input.close();
}
}
