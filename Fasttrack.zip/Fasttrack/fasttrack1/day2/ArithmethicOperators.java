package com.day2;

public class ArithmethicOperators {
public static void main(String[] args) {
	int a=10;
	int b=5;
	String name="anusha";
	String name2="goud";
	//addition
	System.out.println("a+b="+(a+b));
	System.out.println(name+name2); //concatination
    int x = 1+2;  
    String s = "Hello" + " world";  
    System.out.println(x);  
    System.out.println(s);  
  //subtraction
	System.out.println("a-b="+(a-b));
	int z = 1;  
    int y = 12 - z;  
    System.out.println(y);  
  //multiplication
	System.out.println("a*b="+a*b);
    int k = 1;  
    int p= 12 * 2;  
    System.out.println(p);  
  //division
	System.out.println("a/b="+a/b);
	int u=15;
	int d=30/u;
	System.out.println(d);
	//modulo division
	int mod=13%3;
	System.out.println(mod);
	System.out.println("a%b="+a%b);
}
}
