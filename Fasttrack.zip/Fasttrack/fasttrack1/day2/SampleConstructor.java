


package com.day2;

public class SampleConstructor {
	
	public SampleConstructor() {
		
		//Code block constructor general
	}

}
