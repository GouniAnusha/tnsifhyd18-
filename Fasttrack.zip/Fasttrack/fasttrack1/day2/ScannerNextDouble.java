package com.day2;

import java.util.Scanner;

public class ScannerNextDouble {
	public static void main(String[] args) {
		System.out.println("enter your Double value");
		Scanner input= new Scanner(System.in);
	Double doublevalue=input.nextDouble();
		System.out.println("entered double value is "+doublevalue);
		input.close();
}
}