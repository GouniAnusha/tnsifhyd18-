package com.day2;

import java.math.BigInteger;
import java.util.Scanner;

public class NextBigInteger {
	public static void main(String[] args) {
		System.out.println("enter big integer value");
		Scanner input= new Scanner(System.in);
	BigInteger value=input.nextBigInteger();
		System.out.println("entered big integer value is "+value);
		input.close();
}
}