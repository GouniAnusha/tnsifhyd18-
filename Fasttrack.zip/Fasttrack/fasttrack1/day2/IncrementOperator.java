package com.day2;
public class IncrementOperator {
	public static void main(String[] args) {
		

	int x = 10;
    System.out.println(x++);//post increment
    System.out.println(x);
    System.out.println(++x);//pre increment


}
}
