package com.day2;

import java.util.Scanner;

public class ScannerMethods {
 
	public static void main(String[] args) {
		System.out.println("enter float value");
		Scanner input= new Scanner(System.in);
		Float fvalue=input.nextFloat();
		System.out.println("entered float value  "+fvalue);
	

		System.out.println("enter boolean value");
		Scanner input1= new Scanner(System.in);
		boolean bvalue=input1.nextBoolean();
		System.out.println("entered boolean value  "+bvalue);
	
		System.out.println("enter byte value");
		Scanner input2= new Scanner(System.in);
		Byte bytevalue=input2.nextByte();
		System.out.println("entered byte value  "+bytevalue);
	
		System.out.println("enter short value");
		Scanner input3= new Scanner(System.in);
		short svalue=input3.nextShort();
		System.out.println("entered byte value  "+svalue);
	
		System.out.println("enter long value");
		Scanner input4= new Scanner(System.in);
		long lvalue=input4.nextLong();
		System.out.println("entered byte value  "+lvalue);
	


}
}
