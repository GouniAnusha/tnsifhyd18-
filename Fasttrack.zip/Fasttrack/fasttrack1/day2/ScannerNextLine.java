package com.day2;
import java.util.*;
public class ScannerNextLine {
public static void main(String[] args) {
	System.out.println("enter your name");
	Scanner input= new Scanner(System.in);
	String name=input.nextLine();
	System.out.println("my name is  "+name);
	input.close();
}//reads entire line using nextLine() method;
}
