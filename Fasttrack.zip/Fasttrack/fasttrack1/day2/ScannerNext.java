package com.day2;

import java.util.Scanner;

public class ScannerNext {
	public static void main(String[] args) {
		System.out.println("enter your name");
		Scanner input= new Scanner(System.in);
		String name=input.next();
		System.out.println("my name is  "+name);
		input.close();
}
}//reads entire word using next() method;
