package com.day2;

import java.math.BigDecimal;
import java.util.Scanner;

public class NextBigDecimal {
	public static void main(String[] args) {
		System.out.println("enter your NextBigDecimal value");
		Scanner input= new Scanner(System.in);
	BigDecimal value=input.nextBigDecimal();
		System.out.println("entered next big decimal is "+value);
		input.close();
}
}