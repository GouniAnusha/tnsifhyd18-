package com.day4;

import java.util.Iterator;

import java.util.TreeSet;

public class TreeSet1 {
	public static void main(String[] args) {
		
	TreeSet<String> hs = new TreeSet<String>();
	  
    hs.add("welcome");
   hs.add("to");
   hs.add("sriindu");
   hs.add("college of");
   hs.add("engineering and technology");
Iterator<String> itr=hs.iterator();
while(itr.hasNext())
{
	System.out.println(itr.next());
}
}
}
