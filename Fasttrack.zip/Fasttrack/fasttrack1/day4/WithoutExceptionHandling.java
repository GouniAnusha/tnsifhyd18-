package com.day4;

public class WithoutExceptionHandling {
    public static void main(String[] args) {  
        
        int data=50/0; //may throw exception   
          
        System.out.println("rest of the code");  
          
    }  

}
