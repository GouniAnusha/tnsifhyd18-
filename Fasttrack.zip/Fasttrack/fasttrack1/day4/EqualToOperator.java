package com.day4;

public class EqualToOperator {
public static void main(String[] args) {
	String s1="anusha";  
	   String s2="anusha";  
	   String s3=new String("anusha");  
	   String s4="bindu";  
	   System.out.println(s1==s2);  
	   System.out.println(s1==s3);  
	   System.out.println(s1==s4);
	 }  

}

