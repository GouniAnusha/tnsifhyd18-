package com.day4;

import java.util.ArrayList;

public class ArrayList1 {
public static void main(String[] args) {
    ArrayList<Integer>  al= new ArrayList <Integer>();

// Appending new elements at
// the end of the list
for (int i = 1; i <= 5; i++)
    al.add(i);

// Printing elements
System.out.println(al);
al.remove(2);
System.out.println(al);
for (int i = 0; i < al.size(); i++)
    System.out.print(al.get(i) + " ");

}
}
