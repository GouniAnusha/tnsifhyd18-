package com.day4;

public class StringConcat {
public static void main(String[] args) {
	String a="anu";
	String b=new String("bin");
	System.out.println(a.concat(b));
}
}
