package com.day4;

public class MainMultiThreadingRunnableInterface {
	 public static void main(String[] args) {
	        Thread object = new Thread(new MultiThreadingRunnableInterface());
	        object.start();
	        for (int i = 0; i < 10; i++) {
	            System.out.println("Main Thread id: " + Thread.currentThread().getId());
	        }
}
}