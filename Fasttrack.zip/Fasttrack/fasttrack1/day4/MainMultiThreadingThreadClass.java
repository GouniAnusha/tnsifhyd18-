package com.day4;

public class MainMultiThreadingThreadClass {
	 public static void main(String[] args) { 
         
		 MultiThreadingThreadClass object = new MultiThreadingThreadClass();
             object.start();
         for(int i=0;i<5;i++){
             // Displaying the thread that is running
             System.out.println ("main Thread " +
                   Thread.currentThread().getId() +
                   " is running");
             }
     }
}
