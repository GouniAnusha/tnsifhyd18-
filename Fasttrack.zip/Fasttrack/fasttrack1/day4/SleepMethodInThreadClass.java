package com.day4;

public class SleepMethodInThreadClass extends Thread {
	 public void run(){  
		  for(int i=1;i<5;i++){  
		    try{
		    	Thread.sleep(500);
		    	}
		    catch(InterruptedException e)
		    {
		    	System.out.println(e);
		    	}  
		    System.out.println(i);  
		  }  
		 }  
		 public static void main(String args[]){  
			 SleepMethodInThreadClass t1=new SleepMethodInThreadClass();  
		t1.start();  
		}  

}
