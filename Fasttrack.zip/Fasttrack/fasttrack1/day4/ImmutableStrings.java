package com.day4;

public class ImmutableStrings {
public static void main(String[] args) {
	   String s="anusha";  
	   s.concat(" goud");//concat() method appends the string at the end  
	   System.out.println(s);
}
}
