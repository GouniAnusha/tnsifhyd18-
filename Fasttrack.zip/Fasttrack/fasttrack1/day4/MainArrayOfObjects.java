package com.day4;

public class MainArrayOfObjects {
public static void main(String[] args) {
	// ArrayOfObjects arr[];
	ArrayOfObjects arr[]=new  ArrayOfObjects[4];
	arr[0]=new  ArrayOfObjects(1,"anusha");
	arr[1]= new ArrayOfObjects(2,"bindu");
	arr[2]=new  ArrayOfObjects(3,"sujatha");
	arr[3]= new ArrayOfObjects(4,"raju");
    for (int i = 0; i < arr.length; i++)
        System.out.println("Element at " + i + " : " +
                    arr[i].id +" "+ arr[i].name);

}
}
