package com.day4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class HashMap1 {
public static void main(String[] args) {
	HashMap<Integer, String> hs= new HashMap<Integer, String>();
	  
    hs.put(1,"welcome");
   hs.put(2,"to");
   hs.put(3,"sriindu");
   hs.put(4,"college of");
   hs.put(5,"engineering and technology");
   System.out.println("Value for 1 is " + hs.get(1));
   for (Map.Entry<Integer, String> e : hs.entrySet())
       System.out.println(e.getKey() + " " + e.getValue());
}
}

