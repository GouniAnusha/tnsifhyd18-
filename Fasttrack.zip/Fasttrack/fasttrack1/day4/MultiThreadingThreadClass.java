package com.day4;

public class MultiThreadingThreadClass extends Thread{
    public void run()
    {
        try
        {
            for(int i=0;i<5;i++){
            // Displaying the thread that is running
            System.out.println ("Thread " +
                  Thread.currentThread().getId() +
                  " is running");
            }
        }
        catch (Exception e)
        {
            // Throwing an exception
            System.out.println ("Exception is caught");
        }
  }

}

