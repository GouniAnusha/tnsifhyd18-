package com.day4;


import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSet1 {
	public static void main(String[] args) {
		
LinkedHashSet<String> hs = new LinkedHashSet<String>();
	  
     hs.add("welcome");
    hs.add("to");
    hs.add("sriindu");
    hs.add("college of");
    hs.add("engineering and technology");
Iterator<String> itr=hs.iterator();
while(itr.hasNext())
{
	System.out.println(itr.next());
}
}
}
