package com.day4;

public class String2 {
public static void main(String[] args) {
	char ch[]={'s','t','r','i','n','g','s'};    
	String s=new String(ch);//converting char array to string    
System.out.println(ch);
}
}
