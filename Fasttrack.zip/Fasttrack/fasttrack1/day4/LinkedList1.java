package com.day4;


import java.util.LinkedList;

public class LinkedList1 {
public static void main(String[] args) {
	 LinkedList<Integer>  al= new LinkedList<Integer>();

	// Appending new elements at
	// the end of the list
	for (int i = 1; i <= 5; i++)
	    al.add(i);

	// Printing elements
	System.out.println(al);
	al.remove(2);
	System.out.println(al);
	for (int i = 0; i < al.size(); i++)
	    System.out.print(al.get(i) + " ");

	}
}

