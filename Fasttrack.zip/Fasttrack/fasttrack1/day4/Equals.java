package com.day4;

public class Equals {
	public static void main(String[] args) {
		
	
	String s1="anusha";  
	   String s2="anusha";  
	   String s3=new String("bindu");  
	   String s4="anusha";  
	   System.out.println(s1.equals(s2));
	   System.out.println(s1.equals(s3));
	   System.out.println(s1.equals(s4));
	 }  

}
