package com.day4;

public class CompareTo {
public static void main(String[] args) {
	   String s1="Anusha";  
	   String s2="anusha";  
	   String s3="Anusha";  
	   System.out.println(s1.compareTo(s2));
	   System.out.println(s1.compareTo(s3));
	   System.out.println(s3.compareTo(s1));
	 }  

}

