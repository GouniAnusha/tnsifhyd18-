package com.day4;

import java.util.HashSet;
import java.util.Iterator;

public class HashSet1 {
public static void main(String[] args) {
	HashSet<String> hs = new HashSet<String>();
	  
    
    hs.add("welcome");
    hs.add("to");
    hs.add("sriindu");
    hs.add("college of");
    hs.add("engineering and technology");
Iterator<String> itr=hs.iterator();
while(itr.hasNext())
{
	System.out.println(itr.next());
}
}
}
