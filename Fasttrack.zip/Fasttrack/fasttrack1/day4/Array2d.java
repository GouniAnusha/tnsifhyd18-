package com.day4;

public class Array2d {
public static void main(String1[] args) {

     int a[][] = { {2,7,9},{3,6,1},{7,4,2} ,{1,2,3}};
	for (int i=0; i< 4 ; i++)
        	{
            for (int j=0; j < 3 ; j++)
                System.out.print(a[i][j] + " ");
            System.out.println();
        }
    }

}

