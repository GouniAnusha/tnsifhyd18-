package com.day4;

public class StringBuffer1 {
	public static void main(String[] args) {
		
	StringBuffer sb=new StringBuffer("Hello ");  
	sb.append("world");
	System.out.println(sb);
	sb.insert(1, "i H");
	System.out.println(sb);
	sb.delete(1, 2);
	System.out.println(sb);
	sb.replace(1, 3,"anusha");
	System.out.println(sb);
	sb.reverse();
	System.out.println(sb);
	}  
//buffer is synchronized and introduced in java1.0 version
	
}