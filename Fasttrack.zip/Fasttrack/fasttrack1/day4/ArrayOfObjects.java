package com.day4;

public class ArrayOfObjects {
public int id;
public String name;
ArrayOfObjects(int id,String name)
{
	this.id=id;
	this.name=name;
}
}
