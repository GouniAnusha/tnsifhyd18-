package com.day4;
import java.lang.*;
public class ArithmeticExceptionHandling {
	
		  public static void main(String args[]){  
		   try{  
		     
		      int data=5/0;  
		   }catch(ArithmeticException e)
		   {System.out.println(e);
		   }  
		  System.out.println("rest of the code...");  
		  }  
}
