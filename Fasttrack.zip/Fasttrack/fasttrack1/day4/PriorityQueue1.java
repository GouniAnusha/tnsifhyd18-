package com.day4;

import java.util.PriorityQueue;

public class PriorityQueue1 {
public static void main(String[] args) {
    PriorityQueue<String> pQueue = new PriorityQueue<String>();
pQueue.add("anusha");
pQueue.add("bindu");
pQueue.add("sujatha");
pQueue.add("raju");

System.out.println(pQueue.peek());
System.out.println(pQueue.poll());

System.out.println(pQueue.peek());

}
}
