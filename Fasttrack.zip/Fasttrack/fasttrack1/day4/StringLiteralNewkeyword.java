package com.day4;

public class StringLiteralNewkeyword {
public static void main(String[] args) {
	
		String s1="anusha";//creating string by Java string literal      
		String s2=new String("goud");//creating Java string by new keyword    
		System.out.println(s1);    
		System.out.println(s2);    
	   
		
}
}
