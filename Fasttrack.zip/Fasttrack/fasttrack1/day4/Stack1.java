package com.day4;

import java.util.Iterator;
import java.util.Stack;

public class Stack1 {
public static void main(String[] args) {
    Stack<String> stack = new Stack<String>();
    stack.push("welcome");
    stack.push("to");
    stack.push("sriindu");
    stack.push("college");
    Iterator<String> itr  = stack.iterator();
    while (itr.hasNext()) {
        System.out.print(itr.next() + " ");
    }
        System.out.println();
        
        stack.pop();
        itr= stack.iterator();
        while (itr.hasNext()) {
            System.out.print(itr.next() + " ");
        }
}
}

