package com.day4;

public class ArrayOutOfBound {
public static void main(String[] args) {
	int a[]=new int[5];
	try
	{
		System.out.println(a[5]);
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println(e);
	}
}
}
