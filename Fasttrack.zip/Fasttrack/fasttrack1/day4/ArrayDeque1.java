package com.day4;

import java.util.ArrayDeque;

public class ArrayDeque1 {
public static void main(String[] args) {
    ArrayDeque<Integer> arrdeque
    = new ArrayDeque<Integer>(10);

// add() method to insert
    arrdeque.add(10);
    arrdeque.add(20);
    arrdeque.add(30);
    arrdeque.add(40);
    arrdeque.add(50);

System.out.println(arrdeque);

// clear() method
arrdeque.clear();
//addFirst() method to insert the
// elements at the head
arrdeque.addFirst(564);
arrdeque.addFirst(291);

// addLast() method to insert the
// elements at the tail
arrdeque.addLast(24);
arrdeque.addLast(14);

System.out.println(arrdeque);


}
}
