package com.day4;

public class Array1d {
	public static void main(String[] args) {
		
		String a[]=new String[4];
		a[0]="anusha";
		a[1]="bindu";
		a[2]="sujatha";
		a[3]="raju";
		for(int i=0;i<a.length;i++) {
System.out.println(a[i]);}
	}

}
