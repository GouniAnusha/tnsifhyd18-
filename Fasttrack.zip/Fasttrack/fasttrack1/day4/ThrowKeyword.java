package com.day4;

public class ThrowKeyword {

		static void ageLimit(int age){  
		     if(age<18)  
		      throw new ArithmeticException("not valid/not eligible for voting");  
		     else  
		      System.out.println("eligible for voting ");  
		   }  
		   public static void main(String args[]){  
		      ageLimit(14);  
		      System.out.println("rest of the code...");  
		  }  

}
