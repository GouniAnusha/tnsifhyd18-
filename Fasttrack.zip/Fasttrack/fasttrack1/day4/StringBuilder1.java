package com.day4;

public class StringBuilder1 {
public static void main(String[] args) {
	StringBuilder s1=new StringBuilder("anusha");
	System.out.println(s1);
	s1.append("goud");
	System.out.println(s1);
	s1.insert(0, "G ");
	System.out.println(s1);
	s1.delete(0, 1);
	System.out.println(s1);
	s1.replace(0, 1,"gouni");
	System.out.println(s1);
	s1.reverse();
	System.out.println(s1);
}//it is more efficient that buffer and non synchronized and introduced in java 1.5
}
