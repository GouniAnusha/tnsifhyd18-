package com.day4;
import java.io.IOException; 
public class ThrowsKeyword1 {
	 
	  void m()throws IOException{  
	    throw new IOException("device error");//checked exception  
	  }  
	  void n()throws IOException{  
	    m();  
	  }  
	  void p(){  
		   try{  
		    n();  
		   }catch(Exception e){System.out.println("exception handled");}  
		  }  
		  public static void main(String args[]){  
			  ThrowsKeyword1 obj=new ThrowsKeyword1();  
		   obj.p();  
		   System.out.println("normal flow...");  
		  }  
		} 

