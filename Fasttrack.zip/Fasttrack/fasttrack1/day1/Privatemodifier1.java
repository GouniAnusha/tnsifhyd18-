package com.day1;

public class Privatemodifier1 {
	
	public static void main(String args[])
	{
		Privatemodifier1 obj = new Privatemodifier1();
	
	obj.display(); //accessible only within class
	}
	}


