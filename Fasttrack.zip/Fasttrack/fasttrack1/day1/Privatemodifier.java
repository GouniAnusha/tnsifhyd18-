package com.day1;

public class Privatemodifier {
	
	private void display()
	{
	System.out.println("TNS Sessions");
	}
	
	}


