package com.day5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UserDetailsMysql {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				String dbURL = "jdbc:mysql://localhost:3306/db";
				String username = "root";
				String password = "anusha";
				 
				try {
				 
				    Connection conn = DriverManager.getConnection(dbURL, username, password);
				    if (conn != null) 
				    {
				        System.out.println("Connected to the database");
				        conn.close();
				    }
				} catch (SQLException ex) {
					ex.printStackTrace();
				    		

				}
			}

	
}
