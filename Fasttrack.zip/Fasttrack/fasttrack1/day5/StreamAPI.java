package com.day5;

import java.util.PriorityQueue;
import java.util.stream.Stream;

public class StreamAPI

{public static void main(String[] args) {
	String c;
	String a="anusha";
	String b="bindu";
	System.out.println("c="+a.concat(b));
		// TODO Auto-generated method stub
PriorityQueue<Integer> ab=new PriorityQueue<Integer>();
for (int i = 1; i <= 5; i++)
    ab.add(i);

// Printing elements
System.out.println(ab);
System.out.println(ab.peek());
}
}
//Stream<String> onceModifiedStream =
//Stream.of("abcd", "bbcd", "cbcd").skip(1);
	/*Creating Streams
	concat()
	empty()
	generate()
	iterate()
	of()
	Intermediate Operations
	filter()
	map()
	flatMap()
	distinct()
	sorted()
	peek()
	limit()
	skip()
	Terminal Operations
	forEach()
	forEachOrdered()
	toArray()
	reduce()
	collect()
	min()
	max()
	count()
	anyMatch()
	allMatch()
	noneMatch()
	findFirst()
	findAny()*/

