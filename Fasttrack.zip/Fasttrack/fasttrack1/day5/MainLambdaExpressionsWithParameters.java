package com.day5;

public class MainLambdaExpressionsWithParameters {
public static void main(String[] args) {
	LambdaExpressionsWithParameters1 l =(age)->
	{
		return "my age="+age;
	};
	System.out.println(l.Sample(18));
}
}
