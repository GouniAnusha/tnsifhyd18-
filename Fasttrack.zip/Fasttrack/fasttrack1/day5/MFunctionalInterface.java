package com.day5;

public class MFunctionalInterface implements FunctionalInterface1{
public void demo()
{
	System.out.println("functional interface");

}
}