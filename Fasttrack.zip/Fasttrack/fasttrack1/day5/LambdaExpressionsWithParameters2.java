package com.day5;

public interface LambdaExpressionsWithParameters2 {
public void add(int a,int b);
}
