package com.day5;

public interface InterfaceComponent {
public void name1();
public void name2();
}
