package com.day5;

public interface LambdaExpressionsWithParameters1 {
public String Sample(int age);

}
