package com.day5;

public class WithoutComponent1 implements InterfaceComponent {
public void name1()
{
	System.out.println("anusha");
}
public void name2()
{
	System.out.println("bindu");
}
public static void main(String[] args) {
	WithoutComponent1 a=new WithoutComponent1();
	a.name1();
	a.name2();
}
}
