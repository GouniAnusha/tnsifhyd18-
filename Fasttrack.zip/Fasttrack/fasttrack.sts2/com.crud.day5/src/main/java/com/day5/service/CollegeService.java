package com.day5.service;

import java.util.List;

import com.day5.entity.College;

public interface CollegeService {

	public College saveCollege(College college);

public	List<College> fetchCollegeList();

public	College fetchCollegeById(Long collegeCode);

public	void deleteCollegeById(Long collegeCode);

	public College updateCollege(Long collegeCode, College college);


	

}
