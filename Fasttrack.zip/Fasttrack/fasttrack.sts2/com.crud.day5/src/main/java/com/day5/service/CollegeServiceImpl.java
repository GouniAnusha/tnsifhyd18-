package com.day5.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.day5.entity.College;
import com.day5.repository.CollegeRepository;

@Service
public class CollegeServiceImpl implements CollegeService{
	@Autowired
	CollegeRepository collegeRepository;
	private Object collegeDB;

	@Override
	public College saveCollege(College college) {
		// TODO Auto-generated method stub
		return collegeRepository.save(college) ;
	}

	@Override
	public List<College> fetchCollegeList() {
		// TODO Auto-generated method stub
		return collegeRepository.findAll();
	}

	@Override
	public College fetchCollegeById(Long collegeCode) {
		// TODO Auto-generated method stub
		return collegeRepository.findById(collegeCode).get();
	}

	@Override
	public void deleteCollegeById(Long collegeCode) {
		// TODO Auto-generated method stub
		collegeRepository.deleteById(collegeCode);
	}

	@Override
	public College updateCollege(Long collegeCode, College college) {
		// TODO Auto-generated method stub
		 College collegeDB=collegeRepository.findById(collegeCode).get();
	

	 if(Objects.nonNull(college.getCollegeName()) &&
			    !"".equalsIgnoreCase(college.getCollegeName())) {
			    	collegeDB.setCollegeName(college.getCollegeName());
			    }

			    if(Objects.nonNull(college.getCollegeAddress()) &&
			            !"".equalsIgnoreCase(college.getCollegeAddress())) {
			    	collegeDB.setCollegeAddress(college.getCollegeAddress());
			    }

			    if(Objects.nonNull(college.getCollegePincode())&&
			            !"".equals(college.getCollegePincode())){
			    	collegeDB.setCollegePincode(college.getCollegePincode());
			    }

				return collegeRepository.save(collegeDB);
			}

}