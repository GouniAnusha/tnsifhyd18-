package com.day5.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.day5.entity.College;
import com.day5.service.CollegeService;

@RestController
public class CollegeController {

	@Autowired
	CollegeService collegeService;
	
	
	
	 @PostMapping("/colleges")
	    public College saveCollege(@RequestBody College college) {
	       
	        return collegeService.saveCollege(college);
	    }
	 @GetMapping("/colleges")
	    public List<College> fetchCollegeList() {
	       
	        return collegeService.fetchCollegeList();
	    }  
	   @GetMapping("/colleges/{code}")
	    public College fetchCollegeById(@PathVariable("code") Long collegeCode)
	            {
	        return collegeService.fetchCollegeById(collegeCode);
	    }
	   @DeleteMapping("/colleges/{code}")
	    public String deleteCollegeById(@PathVariable("code") Long collegeCode) {
	        collegeService.deleteCollegeById(collegeCode);
	        return "College deleted Successfully!!";
	    }
	   @PutMapping("/colleges/{code}")
	    public College updateCollege(@PathVariable("code") Long collegeCode,
	                                       @RequestBody College college) {
	        return collegeService.updateCollege(collegeCode,college);
	    }
	    

}

