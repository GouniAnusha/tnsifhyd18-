package com.day5;

import org.springframework.stereotype.Component;

@Component
public class InjectingClass1 
{
	private String cousedetails;
public void course1()
{
	System.out.println("cse");
}
public String getCousedetails() {
	return cousedetails;
}
public void setCousedetails(String cousedetails) {
	this.cousedetails = cousedetails;
}
}
