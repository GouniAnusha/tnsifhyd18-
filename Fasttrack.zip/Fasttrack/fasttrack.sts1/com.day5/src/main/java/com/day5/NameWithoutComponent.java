package com.day5;

public interface NameWithoutComponent {
public String name();

}
