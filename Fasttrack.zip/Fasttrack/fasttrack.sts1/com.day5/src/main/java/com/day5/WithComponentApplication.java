package com.day5;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class WithComponentApplication {
	public static void main(String[] args) {
		

	AnnotationConfigApplicationContext context = 
			new	AnnotationConfigApplicationContext(AppConfig.class);
		
		NameWithComponent yourname = context.getBean("person1",NameWithComponent.class);
		System.out.println(yourname.name());
		context.close();
		
}
}
