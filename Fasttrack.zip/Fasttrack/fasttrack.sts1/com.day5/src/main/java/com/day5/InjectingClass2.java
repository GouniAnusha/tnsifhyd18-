package com.day5;

import org.springframework.stereotype.Component;

@Component
public class InjectingClass2 {
public void college()
{
	System.out.println("sriindu");
}
}
