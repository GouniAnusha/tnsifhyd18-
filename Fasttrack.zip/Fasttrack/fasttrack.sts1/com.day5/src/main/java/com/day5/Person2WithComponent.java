package com.day5;

import org.springframework.stereotype.Component;

@Component("person2")
public class Person2WithComponent implements NameWithComponent {
	public String name()
	{
		return "anusha";
		
	}
}
