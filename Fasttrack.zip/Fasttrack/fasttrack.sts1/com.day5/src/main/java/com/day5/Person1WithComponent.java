package com.day5;

import org.springframework.stereotype.Component;

@Component("person1")
public class Person1WithComponent implements NameWithComponent{
	public String name()
	{
		return "anusha";
		
	}
}
