package com.day5;

public class Person1WithoutComponent implements NameWithoutComponent {
public String name()
{
	return "anusha";
	
}
}
