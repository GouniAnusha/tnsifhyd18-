package com.day5;

import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class WithoutComponentApplication {

	public static void main(String[] args) {
	

		NameWithoutComponent person1 = new Person1WithoutComponent();
		NameWithoutComponent person2 = new Person2WithoutComponent();
				
		System.out.println(person1.name());
		System.out.println(person2.name());
	}

}
