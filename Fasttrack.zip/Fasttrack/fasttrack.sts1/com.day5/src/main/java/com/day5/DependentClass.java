package com.day5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class DependentClass {

	private int name;
	private String rollno;
	private String id;
	@Autowired
	private InjectingClass1 di1;
	@Autowired
	private InjectingClass2 di2;
	public int getName() {
		return name;
	}
	public void setName(int name) {
		this.name = name;
	}
	public String getRollno() {
		return rollno;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public InjectingClass1 getDi1() {
		return di1;
	}
	public void setDi1(InjectingClass1 di1) {
		this.di1 = di1;
	}
	public void display()
	{
		di1.course1();
		di2.college();}
}
