package com.day5;

public class Person2WithoutComponent implements NameWithoutComponent {
public String name()
{
	return "bindu";
	
}
}
