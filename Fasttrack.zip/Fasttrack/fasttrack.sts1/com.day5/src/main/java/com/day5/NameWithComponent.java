package com.day5;

public interface NameWithComponent {
public String name();

}
